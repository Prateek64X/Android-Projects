package com.simple.notificationkiller;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.NotificationManager;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private Button notifb;
    boolean isDNDEnabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Defining notifb Button
        notifb = (Button) findViewById(R.id.notifb);
        //Functioning part of Button
        addListenerOnButton ();
    }

    private void addListenerOnButton () {
        notifb.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //killnotif(): Function to Configure the notification channel (Enable Do not Disturb)
                killnotif();
            }
        });
    }

    private void killnotif() {
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            //Check for permissions: Check if the notification policy access has been granted for the app
            if (!mNotificationManager.isNotificationPolicyAccessGranted()) {
                Intent intent = new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                startActivity(intent);
            }

        //Enable Do not Disturb (DND)
        if (!isDNDEnabled) {
            //It allows only Alarms and disables rest of interruptions (ex: notifications, notification sounds, call sounds but allows banner of call)
            mNotificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            isDNDEnabled = true;

            //Show message using toast
            Toast.makeText(getApplicationContext() , "Notifications are disabled!",Toast.LENGTH_SHORT).show();
        }
        //Disable DND
        else
        {
            mNotificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
            isDNDEnabled = false;

            //Show message using toast
            Toast.makeText(getApplicationContext() , "Notifications are enabled",Toast.LENGTH_SHORT).show();
        }
    }

}